/*
Filename: Digit_Counter.h
Filepath: ...\ITSE-2445-Programming 3 - Data Structures - C++\Module 9 Templates and Recursion\Recursion_Lab_1\Digit_Counter.h
Author: Andrew Pettus
Date Created: October 8, 2023
Date Modified:October 8, 2023
Description: Module 9 Recursion and Templates; Digit_Counter.h
License: NLR
--------------------------------------------------------------------------------------------------------------------------
*/

#ifndef DIGIT_COUNTER_H
#define DIGIT_COUNTER_H

// Function prototype for DigitCount
int DigitCount(int number);

#endif // DIGITCOUNTER_H
