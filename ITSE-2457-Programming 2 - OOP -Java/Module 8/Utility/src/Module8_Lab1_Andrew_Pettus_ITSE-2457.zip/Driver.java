/*
 * ITSE-2457; OOP Java; M/W 2pm
 * Written by Andrew Pettus
 * Apr 7 2023
 * Module 8 Lab 1
 * We the people Utility Driver
 */

public class Driver {
    public static void main(String[] args) {
        Utility.countWords();
        Utility.countWe();
        Utility.replacePeople();
    }
}