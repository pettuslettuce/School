/*
 * ITSE-2457; OOP Java; M/W 2pm
 * Written by Andrew Pettus
 * Mar 18 2023
 * Module 6 Lab 2
 * Parking Permit Header
 */
 //Your program will also have a Header class that will serve as the application's title. 
 //A static function that will display a Welcome to the Parking Permit. This will be displayed to welcome the user to the program. 
public class Header {
    public static void displayHeader() {
        System.out.println("Welcome to the Parking Permit");
    }
}